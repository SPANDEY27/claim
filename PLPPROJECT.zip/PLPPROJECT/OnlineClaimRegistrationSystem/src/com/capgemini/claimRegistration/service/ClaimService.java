package com.capgemini.claimRegistration.service;

import java.util.List;

import com.capgemini.claimRegistration.exception.ClaimException;
import com.capgemini.claimRegistration.model.Accounts;
import com.capgemini.claimRegistration.model.Claim;
import com.capgemini.claimRegistration.model.ClaimQuestions;

public interface ClaimService {

	boolean isValidClaimReason(String claimReason) throws ClaimException;

	boolean isValidAccidentCity(String accidentCity) throws ClaimException;

	boolean isValidAccidentLocation(String accidentLocation)
			throws ClaimException;

	boolean isValidAccidentState(String accidentState) throws ClaimException;

	boolean isValidAccidentZip(long accidentZip) throws ClaimException;

	boolean isValidClaimType(String claimType) throws ClaimException;

	long insertClaimDetails(Claim claim) throws ClaimException;

	List<Claim> getAllClaims() throws ClaimException;

	List<ClaimQuestions> getAllClaimQuestions(long policyNumber)
			throws ClaimException;

	List<Claim> getAllclaimReport() throws ClaimException;

	List<Claim> showInsuredClaims(String userName) throws ClaimException;

	List<Accounts> getAllAccounts(String userName) throws ClaimException;

	List<Claim> showAgentClaims(Long policyNumber) throws ClaimException;

	Claim getClaimDetails(long claimNumber) throws ClaimException;

	String getClaimQuestions(int questionId) throws ClaimException;

	List<Claim> showAgentCustomerClaim(long accountNumber)
			throws ClaimException;

}
