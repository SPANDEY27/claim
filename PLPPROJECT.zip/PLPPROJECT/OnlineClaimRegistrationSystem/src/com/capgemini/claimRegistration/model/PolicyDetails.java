package com.capgemini.claimRegistration.model;

import java.io.Serializable;

public class PolicyDetails implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long policyNumber;
	private Integer questionID;
	private String answer;

	public PolicyDetails() {
		// TODO Auto-generated constructor stub
	}

	public PolicyDetails(Long policyNumber, Integer questionID, String answer) {
		super();
		this.policyNumber = policyNumber;
		this.questionID = questionID;
		this.answer = answer;
	}

	public Long getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(Long policyNumber) {
		this.policyNumber = policyNumber;
	}

	public Integer getQuestionID() {
		return questionID;
	}

	public void setQuestionID(Integer questionID) {
		this.questionID = questionID;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

}
