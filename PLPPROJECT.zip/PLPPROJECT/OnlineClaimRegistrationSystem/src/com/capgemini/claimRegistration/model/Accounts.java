package com.capgemini.claimRegistration.model;

import java.io.Serializable;

public class Accounts implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long accountNumber;
	private String insuredName;
	private String userName;
	
	public Accounts() {
		// TODO Auto-generated constructor stub
	}

	public Accounts(Long accountNumber, String insuredName, String userName) {
		super();
		this.accountNumber = accountNumber;
		this.insuredName = insuredName;
		this.userName = userName;
	}

	public Long getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(Long accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getInsuredName() {
		return insuredName;
	}

	public void setInsuredName(String insuredName) {
		this.insuredName = insuredName;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	@Override
	public String toString() {
		return "Accounts [accountNumber=" + accountNumber + ", insuredName="
				+ insuredName + ", userName=" + userName + "]";
	}
	
	

}
