package com.capgemini.claimRegistration.dao;

import com.capgemini.claimRegistration.exception.ClaimException;
import com.capgemini.claimRegistration.model.UserRole;

public interface ProfileCreationDao {

	int profileCreation(UserRole role2)throws ClaimException;

}
