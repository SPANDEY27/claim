package com.capgemini.claimRegistration.daoImpl.test;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.claimRegistration.daoImpl.ReportGenerationDaoImpl;
import com.capgemini.claimRegistration.exception.ClaimException;
import com.capgemini.claimRegistration.model.Claim;

public class ReportGenerationDaoImplTest {
	
	ReportGenerationDaoImpl report = null;

	@Before
	public void setUp() throws Exception {
		report = new ReportGenerationDaoImpl();
	}

	@After
	public void tearDown() throws Exception {
		report = null;
	}

	@Test
	public void testGetAllclaimReportNot() {
		 List<Claim> list = new ArrayList<>();
		try {
			list = report.getAllclaimReport();
			assertNotNull(list);
		} catch (ClaimException e) {
			
			e.printStackTrace();
		}
	}
	@Test
	public void testGetAllclaimReport() {
		 List<Claim> list = new ArrayList<>();
		try {
			list = report.getAllclaimReport();
			assertNull(list);
		} catch (ClaimException e) {
			
			e.printStackTrace();
		}
	}

}
