package com.cg.model;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "BussinessSegment")
public class BussinessSegment {
	@Id
	@Column(name = "busSegId")
	String busSegId;
	@Column(name = "busSegSeq")
	int busSegSeq;
	@Column(name = "busSegName")
	String busSegName;

	public BussinessSegment() {
		super();

	}

	public BussinessSegment(String busSegId, int busSegSeq, String busSegName) {
		super();
		this.busSegId = busSegId;
		this.busSegSeq = busSegSeq;
		this.busSegName = busSegName;
	}

	public String getBusSegId() {
		return busSegId;
	}

	public void setBusSegId(String busSegId) {
		this.busSegId = busSegId;
	}

	public int getBusSegSeq() {
		return busSegSeq;
	}

	public void setBusSegSeq(int busSegSeq) {
		this.busSegSeq = busSegSeq;
	}

	public String getBusSegName() {
		return busSegName;
	}

	public void setBusSegName(String busSegName) {
		this.busSegName = busSegName;
	}

	@Override
	public String toString() {
		return "BussinessSegment [busSegId=" + busSegId + ", busSegSeq=" + busSegSeq + ", busSegName=" + busSegName
				+ "]";
	}

}
