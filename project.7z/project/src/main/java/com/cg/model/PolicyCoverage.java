package com.cg.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "PolicyCoverage")
public class PolicyCoverage {
	@Id
	@Column(name = "polCoverageId")
	String polCoverageId;
	@Column(name = "polCoverageSegment")
	int polCoverageSegment;
	@Column(name = "busSegId")
	String busSegId;
	@Column(name = "polCoverageDesc")
	String polCoverageDesc;
	@Column(name = "polCoverageAns1")
	String polCoverageAns1;
	@Column(name = "polCoverageAns1Weightage")
	int polCoverageAns1Weightage;
	@Column(name = "polCoverageAns2")
	String polCoverageAns2;
	@Column(name = "polCoverageAns2Weightage")
	int polCoverageAns2Weightage;
	@Column(name = "polCoverageAns3")
	String polCoverageAns3;
	@Column(name = "polCoverageAns3Weightage")
	int polCoverageAns3Weightage;
	@Column(name = "polCoverageAns4")
	String polCoverageAns4;
	@Column(name = "polCoverageAns4Weightage")
	int polCoverageAns4Weightage;
	@Column(name = "polCoverageAns5")
	String polCoverageAns5;
	@Column(name = "polCoverageAns5Weightage")
	int polCoverageAns5Weightage;

	
	public PolicyCoverage() {
		super();
		
	}
	public PolicyCoverage(String polCoverageId, int polCoverageSegment, String busSegId, String polCoverageDesc,
			String polCoverageAns1, int polCoverageAns1Weightage, String polCoverageAns2, int polCoverageAns2Weightage,
			String polCoverageAns3, int polCoverageAns3Weightage, String polCoverageAns4, int polCoverageAns4Weightage,
			String polCoverageAns5, int polCoverageAns5Weightage) {
		super();
		this.polCoverageId = polCoverageId;
		this.polCoverageSegment = polCoverageSegment;
		this.busSegId = busSegId;
		this.polCoverageDesc = polCoverageDesc;
		this.polCoverageAns1 = polCoverageAns1;
		this.polCoverageAns1Weightage = polCoverageAns1Weightage;
		this.polCoverageAns2 = polCoverageAns2;
		this.polCoverageAns2Weightage = polCoverageAns2Weightage;
		this.polCoverageAns3 = polCoverageAns3;
		this.polCoverageAns3Weightage = polCoverageAns3Weightage;
		this.polCoverageAns4 = polCoverageAns4;
		this.polCoverageAns4Weightage = polCoverageAns4Weightage;
		this.polCoverageAns5 = polCoverageAns5;
		this.polCoverageAns5Weightage = polCoverageAns5Weightage;
	}

	public String getPolCoverageId() {
		return polCoverageId;
	}

	public void setPolCoverageId(String polCoverageId) {
		this.polCoverageId = polCoverageId;
	}

	public int getPolCoverageSegment() {
		return polCoverageSegment;
	}

	public void setPolCoverageSegment(int polCoverageSegment) {
		this.polCoverageSegment = polCoverageSegment;
	}

	public String getBusSegId() {
		return busSegId;
	}

	public void setBusSegId(String busSegId) {
		this.busSegId = busSegId;
	}

	public String getPolCoverageDesc() {
		return polCoverageDesc;
	}

	public void setPolCoverageDesc(String polCoverageDesc) {
		this.polCoverageDesc = polCoverageDesc;
	}

	public String getPolCoverageAns1() {
		return polCoverageAns1;
	}

	public void setPolCoverageAns1(String polCoverageAns1) {
		this.polCoverageAns1 = polCoverageAns1;
	}

	public int getPolCoverageAns1Weightage() {
		return polCoverageAns1Weightage;
	}

	public void setPolCoverageAns1Weightage(int polCoverageAns1Weightage) {
		this.polCoverageAns1Weightage = polCoverageAns1Weightage;
	}

	public String getPolCoverageAns2() {
		return polCoverageAns2;
	}

	public void setPolCoverageAns2(String polCoverageAns2) {
		this.polCoverageAns2 = polCoverageAns2;
	}

	public int getPolCoverageAns2Weightage() {
		return polCoverageAns2Weightage;
	}

	public void setPolCoverageAns2Weightage(int polCoverageAns2Weightage) {
		this.polCoverageAns2Weightage = polCoverageAns2Weightage;
	}

	public String getPolCoverageAns3() {
		return polCoverageAns3;
	}

	public void setPolCoverageAns3(String polCoverageAns3) {
		this.polCoverageAns3 = polCoverageAns3;
	}

	public int getPolCoverageAns3Weightage() {
		return polCoverageAns3Weightage;
	}

	public void setPolCoverageAns3Weightage(int polCoverageAns3Weightage) {
		this.polCoverageAns3Weightage = polCoverageAns3Weightage;
	}

	public String getPolCoverageAns4() {
		return polCoverageAns4;
	}

	public void setPolCoverageAns4(String polCoverageAns4) {
		this.polCoverageAns4 = polCoverageAns4;
	}

	public int getPolCoverageAns4Weightage() {
		return polCoverageAns4Weightage;
	}

	public void setPolCoverageAns4Weightage(int polCoverageAns4Weightage) {
		this.polCoverageAns4Weightage = polCoverageAns4Weightage;
	}

	public String getPolCoverageAns5() {
		return polCoverageAns5;
	}

	public void setPolCoverageAns5(String polCoverageAns5) {
		this.polCoverageAns5 = polCoverageAns5;
	}

	public int getPolCoverageAns5Weightage() {
		return polCoverageAns5Weightage;
	}

	public void setPolCoverageAns5Weightage(int polCoverageAns5Weightage) {
		this.polCoverageAns5Weightage = polCoverageAns5Weightage;
	}

	@Override
	public String toString() {
		return "PolicyCoveragetions [polCoverageId=" + polCoverageId + ", polCoverageSegment=" + polCoverageSegment
				+ ", busSegId=" + busSegId + ", polCoverageDesc=" + polCoverageDesc + ", polCoverageAns1="
				+ polCoverageAns1 + ", polCoverageAns1Weightage=" + polCoverageAns1Weightage + ", polCoverageAns2="
				+ polCoverageAns2 + ", polCoverageAns2Weightage=" + polCoverageAns2Weightage + ", polCoverageAns3="
				+ polCoverageAns3 + ", polCoverageAns3Weightage=" + polCoverageAns3Weightage + ", polCoverageAns4="
				+ polCoverageAns4 + ", polCoverageAns4Weightage=" + polCoverageAns4Weightage + ", polCoverageAns5="
				+ polCoverageAns5 + ", polCoverageAns5Weightage=" + polCoverageAns5Weightage + "]";
	}

}
