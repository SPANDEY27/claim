package com.cg.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Policy")
public class Policy {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	long policyNumber;

	@Column(name = "policyPremium")
	double policyPremium;
	@Column(name = "accounNumber")
	long accounNumber;

	public Policy() {
		super();

	}

	public Policy(double policyPremium, long accounNumber) {
		super();

		this.policyPremium = policyPremium;
		this.accounNumber = accounNumber;
	}

	public Policy(long policyNumber, double policyPremium, long accounNumber) {
		super();
		this.policyNumber = policyNumber;
		this.policyPremium = policyPremium;
		this.accounNumber = accounNumber;
	}

	public long getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(long policyNumber) {
		this.policyNumber = policyNumber;
	}

	public double getPolicyPremium() {
		return policyPremium;
	}

	public void setPolicyPremium(double policyPremium) {
		this.policyPremium = policyPremium;
	}

	public long getAccounNumber() {
		return accounNumber;
	}

	public void setAccounNumber(long accounNumber) {
		this.accounNumber = accounNumber;
	}

	@Override
	public String toString() {
		return "Policy [policyNumber=" + policyNumber + ", policyPremium=" + policyPremium + ", accounNumber="
				+ accounNumber + "]";
	}

}
