package com.cg.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "Account")
public class Account {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	long accountNumber;
	@Column(name = "insuredName")
	String insuredName;
	@Column(name = "insuredStreet")
	String insuredStreet;
	@Column(name = "insuredCity")
	String insuredCity;
	@Column(name = "insuredState")
	String insuredState;
	@Column(name = "zip")
	int zip;
	@Column(name = "bussinessSegment")
	String bussinessSegment;
	@Column(name = "userName")
	String userName;

	public Account() {
		super();

	}

	public Account(String insuredName, String insuredStreet, String insuredCity, String insuredState, int zip,
			String bussinessSegment, String userName) {
		super();

		this.insuredName = insuredName;
		this.insuredStreet = insuredStreet;
		this.insuredCity = insuredCity;
		this.insuredState = insuredState;
		this.zip = zip;
		this.bussinessSegment = bussinessSegment;
		this.userName = userName;
	}

	public Account(long accountNumber, String insuredName, String insuredStreet, String insuredCity,
			String insuredState, int zip, String bussinessSegment, String userName) {
		super();
		
		this.insuredName = insuredName;
		this.insuredStreet = insuredStreet;
		this.insuredCity = insuredCity;
		this.insuredState = insuredState;
		this.zip = zip;
		this.bussinessSegment = bussinessSegment;
		this.userName = userName;
	}

	public long getAccountNumber() {
		return accountNumber;
	}

	/*public void setAccountNumber(long accountNumber) {
		accountNumber = accountNumber;
	}
*/
	public String getInsuredName() {
		return insuredName;
	}

	public void setInsuredName(String insuredName) {
		this.insuredName = insuredName;
	}

	public String getInsuredStreet() {
		return insuredStreet;
	}

	public void setInsuredStreet(String insuredStreet) {
		this.insuredStreet = insuredStreet;
	}

	public String getInsuredCity() {
		return insuredCity;
	}

	public void setInsuredCity(String insuredCity) {
		this.insuredCity = insuredCity;
	}

	public String getInsuredState() {
		return insuredState;
	}

	public void setInsuredState(String insuredState) {
		this.insuredState = insuredState;
	}

	public int getZip() {
		return zip;
	}

	public void setZip(int zip) {
		this.zip = zip;
	}

	public String getBussinessSegment() {
		return bussinessSegment;
	}

	public void setBussinessSegment(String bussinessSegment) {
		this.bussinessSegment = bussinessSegment;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	@Override
	public String toString() {
		return "Account [AccountNumber=" + accountNumber + ", insuredName=" + insuredName + ", insuredStreet="
				+ insuredStreet + ", insuredCity=" + insuredCity + ", insuredState=" + insuredState + ", zip=" + zip
				+ ", bussinessSegment=" + bussinessSegment + ", userName=" + userName + "]";
	}

}
