package com.cg.DAO;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;

import com.cg.model.PolicyQuestions;
public class ModelPolicyQuestions {

	  private Session currentSession;
	  private Transaction currentTransaction;
	  
	  public Session openCurrentSession() {
	        currentSession = getSessionFactory().openSession();
	        return currentSession;
	    }
	 
	    public Session openCurrentSessionwithTransaction() {
	        currentSession = getSessionFactory().openSession();
	        currentTransaction = currentSession.beginTransaction();
	        return currentSession;
	    }
	     
	    public void closeCurrentSession() {
	        currentSession.close();
	    }
	     
	    public void closeCurrentSessionwithTransaction() {
	        currentTransaction.commit();
	        currentSession.close();
	    }
	     
	    private static SessionFactory getSessionFactory() {
	        Configuration configuration = new Configuration().configure();
	        StandardServiceRegistryBuilder builder = new StandardServiceRegistryBuilder()
	                .applySettings(configuration.getProperties());
	        SessionFactory sessionFactory = configuration.buildSessionFactory(builder.build());
	        return sessionFactory;
	    }
	 
	    public Session getCurrentSession() {
	        return currentSession;
	    }
	 
	    public void setCurrentSession(Session currentSession) {
	        this.currentSession = currentSession;
	    }
	 
	    public Transaction getCurrentTransaction() {
	        return currentTransaction;
	    }
	 
	    public void setCurrentTransaction(Transaction currentTransaction) {
	        this.currentTransaction = currentTransaction;
	    }
	 
	    public void persist(PolicyQuestions entity) {
	        getCurrentSession().save(entity);
	    }
	 
	    public void update(PolicyQuestions entity) {
	        getCurrentSession().update(entity);
	    }
	 
	    public PolicyQuestions findById(String id) {
	        PolicyQuestions PolicyQuestions = (PolicyQuestions) getCurrentSession().get(PolicyQuestions.class, id);
	        return PolicyQuestions; 
	    }
	 
	    public void delete(PolicyQuestions entity) {
	        getCurrentSession().delete(entity);
	    }
	 
	    @SuppressWarnings("unchecked")
	    public List<PolicyQuestions> findAll() {
	        List<PolicyQuestions> PolicyQuestionss = (List<PolicyQuestions>) getCurrentSession().createQuery("from PolicyQuestions").list();
	        return PolicyQuestionss;
	    }
	 
	    public void deleteAll() {
	        List<PolicyQuestions> entityList = findAll();
	        for (PolicyQuestions entity : entityList) {
	            delete(entity);
	        }
	    }
	}

