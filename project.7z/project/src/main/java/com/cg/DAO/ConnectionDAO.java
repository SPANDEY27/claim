package com.cg.DAO;

import com.cg.model.UserRole;

public class ConnectionDAO {

   public static void main( String[ ] args ) {
   
	   							/*  check path to the cfg.xml */
    /*  SessionFactory sf = new Configuration().configure("/META-INF/hibernate.cfg.xml").buildSessionFactory();*/
      
     /* EntityManager entitymanager = emfactory.createEntityManager( );
      entitymanager.getTransaction( ).begin( );*/
   /*   Session session = sf.openSession();
      session.beginTransaction();*/
	   ModelUserRole ur = new ModelUserRole();
      UserRole country = new UserRole( ); 
      country.setUserName("Faiz@kabul" );
      country.setPassword("Car@12345");
      country.setRoleCode("Admin");
      System.out.println(country);
      ur.openCurrentSession();
      UserRole book = ur.findById("Faiz@kabul");
      System.out.println(book);
      ur.closeCurrentSession();
    //  ur.delete(country);
      ur.closeCurrentSessionwithTransaction();
     /* session.save(country);
      session.getTransaction().commit();*/
  
     // country.setCid(1);
     
      
     /* entitymanager.persist( country );
      entitymanager.getTransaction( ).commit( );
      System.out.println("data entered");*/
     
   }
   
  
}
