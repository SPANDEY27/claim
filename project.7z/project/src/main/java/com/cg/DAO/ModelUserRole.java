package com.cg.DAO;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;

import com.cg.model.UserRole;
public class ModelUserRole implements ModelUserRoleInterface<UserRole ,String>{

	  private Session currentSession;
	  private Transaction currentTransaction;
	  
	  public Session openCurrentSession() {
	        currentSession = getSessionFactory().openSession();
	        return currentSession;
	    }
	 
	    public Session openCurrentSessionwithTransaction() {
	        currentSession = getSessionFactory().openSession();
	        currentTransaction = currentSession.beginTransaction();
	        return currentSession;
	    }
	     
	    public void closeCurrentSession() {
	        currentSession.close();
	    }
	     
	    public void closeCurrentSessionwithTransaction() {
	        currentTransaction.commit();
	        currentSession.close();
	    }
	     
	    private static SessionFactory getSessionFactory() {
	        Configuration configuration = new Configuration().configure("/META-INF/hibernate.cfg.xml");
	        StandardServiceRegistryBuilder builder = new StandardServiceRegistryBuilder()
	                .applySettings(configuration.getProperties());
	        
	        /*ServiceRegistry builder = new ServiceRegistryBuilder().applySettings( configuration.getProperties()). buildServiceRegistry();*/
	        SessionFactory sessionFactory = configuration.buildSessionFactory(builder.build());
	        
	        
	        return sessionFactory;
	    }
	 
	    public Session getCurrentSession() {
	        return currentSession;
	    }
	 
	    public void setCurrentSession(Session currentSession) {
	        this.currentSession = currentSession;
	    }
	 
	    public Transaction getCurrentTransaction() {
	        return currentTransaction;
	    }
	 
	    public void setCurrentTransaction(Transaction currentTransaction) {
	        this.currentTransaction = currentTransaction;
	    }
	 
	    public void persist(UserRole entity) {
	        getCurrentSession().save(entity);
	    }
	 
	    public void update(UserRole entity) {
	        getCurrentSession().update(entity);
	    }
	 
	    public UserRole findById(String id) {
	        UserRole UserRole = (UserRole) getCurrentSession().get(UserRole.class, id);
	        return UserRole; 
	    }
	 
	    public void delete(UserRole entity) {
	        getCurrentSession().delete(entity);
	    }
	 
	    @SuppressWarnings("unchecked")
	    public List<UserRole> findAll() {
	        List<UserRole> UserRoles = (List<UserRole>) getCurrentSession().createQuery("from UserRole").list();
	        return UserRoles;
	    }
	 
	    public void deleteAll() {
	        List<UserRole> entityList = findAll();
	        for (UserRole entity : entityList) {
	            delete(entity);
	        }
	    }
	}

